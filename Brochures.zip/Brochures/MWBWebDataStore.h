//
//  MWBWebDataStore.h
//  Brochures
//
//  Created by Mokhles on 28/02/16.
//  Copyright © 2016 Mohamed Waly. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MWBListNetworkItem;
@interface MWBWebDataStore : NSObject

- (void) fetchEnteriesWithCompletionBlock:(void (^)(MWBListNetworkItem *sectors))completionBlock;
@end

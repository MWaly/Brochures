//
//  MWBDataStoreManager.m
//  Brochures
//
//  Created by Mokhles on 28/02/16.
//  Copyright © 2016 Mohamed Waly. All rights reserved.
//

#import "MWBDataStoreManager.h"

@implementation MWBDataStoreManager

@end

//
//  MWBConstants.m
//  Brochures
//
//  Created by Mokhles on 29/02/16.
//  Copyright © 2016 Mohamed Waly. All rights reserved.
//

#import "MWBConstants.h"

@implementation MWBConstants

NSString *const MWBDataEndPoint = @"https://dl.dropboxusercontent.com/u/41357788/coding_task/api.json";


@end

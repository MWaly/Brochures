//
//  MWBCellElementCollectionViewCell.m
//  Brochures
//
//  Created by Mokhles on 28/02/16.
//  Copyright © 2016 Mohamed Waly. All rights reserved.
//

#import "MWBCellElementCollectionViewCell.h"

@implementation MWBCellElementCollectionViewCell

@end
